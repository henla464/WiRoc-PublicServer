import serial
import time
 # Module sys has to be imported:
import sys


f = open('/dev/ttyUSB5', 'w')
print(f)



